# from flask import Flask, request, jsonify
# from flask_cors import CORS
# from pymongo import MongoClient
# from datetime import datetime
# import pandas as pd
# from sentence_transformers import SentenceTransformer, util
# import traceback
# import json
# import os
# from dotenv import load_dotenv
# import ssl

# print("Starting Flask application...")

# # Load environment variables
# load_dotenv()

# app = Flask(__name__)
# # Configure CORS
# CORS(app, resources={
#     r"/*": {
#         "origins": ["*"],  # In production, replace with your frontend domain
#         "methods": ["GET", "POST", "OPTIONS"],
#         "allow_headers": ["Content-Type"]
#     }
# })

# # Get MongoDB URI from environment variable
# MONGODB_URI = os.getenv('MONGODB_URI')
# if not MONGODB_URI:
#     raise ValueError("MONGODB_URI environment variable is not set")

# print("Connecting to MongoDB Atlas...")
# try:
#     client = MongoClient(MONGODB_URI)
#     # Test the connection
#     client.server_info()
#     db = client.get_database()
#     print("Successfully connected to MongoDB Atlas!")
# except Exception as e:
#     print(f"Error connecting to MongoDB: {str(e)}")
#     print("Full traceback:")
#     print(traceback.format_exc())
#     raise e

# print("Loading dataset...")
# # Load dataset
# df = pd.read_csv("ipc_sections_updated.csv")

# print("Initializing Sentence-BERT model...")
# # Train Sentence-BERT model
# model = SentenceTransformer("paraphrase-MiniLM-L6-v2")
# embeddings = model.encode(df["Description"].tolist(), convert_to_tensor=True)

# def get_relevant_sections(query, df, model, embeddings, top_n=5):
#     """Finds the top-N most relevant sections based on a search query."""
#     if not query.strip():
#         return df.head(top_n)[["Section", "Offense", "Punishment"]].to_dict(orient="records")
    
#     query_embedding = model.encode(query, convert_to_tensor=True)
#     similarity_scores = util.pytorch_cos_sim(query_embedding, embeddings).squeeze()
    
#     top_indices = similarity_scores.argsort(descending=True)[:top_n]
#     results = df.iloc[top_indices][["Section", "Offense", "Punishment"]].copy()
#     results = results[~results["Offense"].str.startswith("IPC Section")]

#     return results.to_dict(orient="records")

# @app.route("/search", methods=["POST"])
# def search_sections():
#     data = request.json
#     query = data.get("query", "")
    
#     results = get_relevant_sections(query, df, model, embeddings)
#     return jsonify(results)

# @app.route('/api/complaints', methods=['POST'])
# def register_complaint():
#     try:
#         data = request.json
#         print(f"Received complaint data: {data}")
        
#         # Validate required fields
#         required_fields = ['name', 'email', 'phone', 'incidentDate', 'location', 'description']
#         for field in required_fields:
#             if field not in data:
#                 return jsonify({'error': f'Missing required field: {field}'}), 400
        
#         complaint_data = {
#             'name': data['name'],
#             'email': data['email'],
#             'phone': data['phone'],
#             'incident_date': datetime.strptime(data['incidentDate'], '%Y-%m-%d'),
#             'location': data['location'],
#             'description': data['description'],
#             'timestamp': datetime.now(),
#             'status': 'Pending'
#         }
        
#         print("Attempting to insert complaint...")
#         result = db.complaints.insert_one(complaint_data)
        
#         if result.inserted_id:
#             print(f"Successfully inserted complaint with ID: {result.inserted_id}")
#             return jsonify({'message': 'Complaint registered successfully'}), 201
#         else:
#             print("Failed to insert complaint - no ID returned")
#             return jsonify({'error': 'Failed to register complaint'}), 500
            
#     except ValueError as e:
#         print(f"Validation error: {str(e)}")
#         return jsonify({'error': f'Invalid date format. Please use YYYY-MM-DD format.'}), 400
#     except Exception as e:
#         print(f"Error registering complaint: {str(e)}")
#         print("Full traceback:")
#         print(traceback.format_exc())
#         return jsonify({'error': str(e)}), 500

# @app.route('/api/complaints', methods=['GET'])
# def get_complaints():
#     try:
#         print("Attempting to fetch complaints...")
#         # Convert ObjectId to string for JSON serialization
#         complaints = list(db.complaints.find({}, {'_id': 0}).sort('timestamp', -1))
#         # Convert datetime objects to ISO format strings
#         for complaint in complaints:
#             if 'timestamp' in complaint:
#                 complaint['timestamp'] = complaint['timestamp'].isoformat()
#             if 'incident_date' in complaint:
#                 complaint['incident_date'] = complaint['incident_date'].isoformat()
        
#         print(f"Successfully fetched {len(complaints)} complaints")
#         return jsonify(complaints)
#     except Exception as e:
#         print(f"Error fetching complaints: {str(e)}")
#         print("Full traceback:")
#         print(traceback.format_exc())
#         return jsonify({'error': str(e)}), 500

# @app.route('/test', methods=['GET'])
# def test():
#     return jsonify({'message': 'Backend is running!'}), 200

# if __name__ == "__main__":
#     print("Starting Flask server...")
#     app.run(debug=True, port=5000)
