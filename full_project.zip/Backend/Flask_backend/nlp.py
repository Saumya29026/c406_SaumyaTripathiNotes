from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
from sentence_transformers import SentenceTransformer, util
import traceback
import os
from dotenv import load_dotenv

print("Starting Flask application...")

# Load environment variables (if needed for future expansion)
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": ["*"],  # In production, replace with your frontend domain
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})

# Define the correct path to the CSV file
# Use raw string (r"") to avoid unicode escape issues
DATASET_PATH = r"D:\MTHREE\UPDATED_PROJECT\Backend\Dataset\ipc_sections_updated.csv"

# Load dataset
print("Loading dataset...")
try:
    if not os.path.exists(DATASET_PATH):
        raise FileNotFoundError(f"Dataset file not found at: {DATASET_PATH}")
    df = pd.read_csv(DATASET_PATH)
    print("Dataset loaded successfully!")
except Exception as e:
    print(f"Error loading dataset: {str(e)}")
    print("Full traceback:")
    print(traceback.format_exc())
    raise e

# Initialize Sentence-BERT model
print("Initializing Sentence-BERT model...")
try:
    model = SentenceTransformer("paraphrase-MiniLM-L6-v2")
    embeddings = model.encode(df["Description"].tolist(), convert_to_tensor=True)
    print("Sentence-BERT model initialized!")
except Exception as e:
    print(f"Error initializing model: {str(e)}")
    print("Full traceback:")
    print(traceback.format_exc())
    raise e

def get_relevant_sections(query, df, model, embeddings, top_n=5):
    """Finds the top-N most relevant sections based on a search query."""
    if not query.strip():
        return df.head(top_n)[["Section", "Offense", "Punishment"]].to_dict(orient="records")
    
    try:
        query_embedding = model.encode(query, convert_to_tensor=True)
        similarity_scores = util.pytorch_cos_sim(query_embedding, embeddings).squeeze()
        
        top_indices = similarity_scores.argsort(descending=True)[:top_n]
        results = df.iloc[top_indices][["Section", "Offense", "Punishment"]].copy()
        
        results = results[~results["Offense"].str.startswith("IPC Section")]
        return results.to_dict(orient="records")
    except Exception as e:
        print(f"Error in get_relevant_sections: {str(e)}")
        print("Full traceback:")
        print(traceback.format_exc())
        raise e

@app.route("/search", methods=["POST"])
def search_sections():
    """Endpoint to search IPC sections based on a natural language query."""
    try:
        data = request.json
        query = data.get("query", "")
        print(f"Received search query: {query}")
        
        results = get_relevant_sections(query, df, model, embeddings)
        print(f"Returning {len(results)} results")
        
        return jsonify(results), 200
    except Exception as e:
        print(f"Error in search_sections: {str(e)}")
        print("Full traceback:")
        print(traceback.format_exc())
        return jsonify({'error': str(e)}), 500

@app.route('/test', methods=['GET'])
def test():
    """Test endpoint to verify the backend is running."""
    return jsonify({'message': 'NLP Backend is running!'}), 200

if __name__ == "__main__":
    print("Starting Flask server...")
    app.run(debug=True, port=5000)