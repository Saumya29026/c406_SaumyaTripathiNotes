#!/bin/bash

# Exit on error
set -e

echo "Building Docker image..."
docker build -t ipc-nexus-backend:latest .

echo "Creating Kubernetes namespace if it doesn't exist..."
kubectl create namespace ipc-nexus --dry-run=client -o yaml | kubectl apply -f -

echo "Applying Kubernetes configurations..."
kubectl apply -f k8s/config.yaml -n ipc-nexus
kubectl apply -f k8s/deployment.yaml -n ipc-nexus
kubectl apply -f k8s/service.yaml -n ipc-nexus
kubectl apply -f k8s/hpa.yaml -n ipc-nexus

echo "Waiting for deployment to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment/ipc-nexus-backend -n ipc-nexus

echo "Getting service URL..."
kubectl get service ipc-nexus-service -n ipc-nexus

echo "Deployment complete! You can check the status with:"
echo "kubectl get pods -n ipc-nexus"
echo "kubectl get services -n ipc-nexus" 