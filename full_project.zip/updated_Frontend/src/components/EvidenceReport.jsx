import React, { useState, useEffect } from "react";
import { Form, Button, Container, Card, Row, Col } from "react-bootstrap";
import "../styles/EvidenceReport.css";

function EvidenceReport() {
  const [complaintId, setComplaintId] = useState("");
  const [policeId, setPoliceId] = useState("");
  const [evidenceFile, setEvidenceFile] = useState(null);
  const [evidenceList, setEvidenceList] = useState([]);

  useEffect(() => {
    const fetchEvidence = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/evidence");
        if (response.ok) {
          const data = await response.json();
          setEvidenceList(data);
        } else {
          console.error("Failed to fetch evidence");
        }
      } catch (error) {
        console.error("Error fetching evidence:", error);
      }
    };

    fetchEvidence();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("complaintId", complaintId);
    formData.append("policeId", policeId);
    formData.append("evidenceFile", evidenceFile);

    fetch("http://localhost:5000/api/evidence", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        alert("Evidence submitted successfully!");
        setEvidenceList([...evidenceList, data]);
      })
      .catch((error) => console.error("Error submitting evidence:", error));
  };

  return (
    <div className="EvidenceReport-bg">
      <Container className="evidence-container">
        <Row>
          <Col md={8}>
            <Card className="evidence-card">
              <h4 className="evidence-title">Evidence Submission</h4>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Complaint ID</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Complaint ID"
                    value={complaintId}
                    onChange={(e) => setComplaintId(e.target.value)}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Police ID</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Police ID"
                    value={policeId}
                    onChange={(e) => setPoliceId(e.target.value)}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-4">
                  <Form.Label>Upload Evidence</Form.Label>
                  <Form.Control
                    type="file"
                    onChange={(e) => setEvidenceFile(e.target.files[0])}
                    required
                  />
                </Form.Group>
                <Button variant="primary" type="submit" className="submit-button">
                  Submit Evidence
                </Button>
              </Form>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="evidence-card">
              <h5 className="existing-evidence-title">Existing Evidence</h5>
              <ul className="evidence-list">
                {evidenceList.map((evidence, index) => (
                  <li key={index} className="evidence-item">
                    <strong>{evidence}</strong>
                    <span>Details</span>
                  </li>
                ))}
              </ul>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default EvidenceReport;
