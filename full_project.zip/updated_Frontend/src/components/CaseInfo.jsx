import React, { useState, useEffect } from "react";
import { Tabs, Tab, Container } from "react-bootstrap";
import "../styles/CaseInfo.css"; // Import the external CSS file

function CaseInfo() {
  const [key, setKey] = useState("assigned");
  const [assignedCases, setAssignedCases] = useState([]);
  const [resolvedCases, setResolvedCases] = useState([]);

  useEffect(() => {
    // Simulated backend call to fetch cases
    const fetchCases = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/cases"); // Replace with actual backend API
        if (response.ok) {
          const data = await response.json();
          setAssignedCases(data.assignedCases || []);
          setResolvedCases(data.resolvedCases || []);
        } else {
          console.error("Failed to fetch cases");
        }
      } catch (error) {
        console.error("Error fetching cases:", error);
      }
    };

    fetchCases();
  }, []);

  return (
    <div className="background-CaseInfo">
      <Container className="case-info-container">
        <div className="tab-container">
          <Tabs
            activeKey={key}
            onSelect={(k) => setKey(k)}
            className="mb-3 tabs"
            justify
          >
            <Tab eventKey="assigned" title={<strong>Assigned Cases</strong>}>
              <div className="tab-content">
                <h3>Assigned Cases</h3>
                {assignedCases.length > 0 ? (
                  assignedCases.map((caseItem, index) => (
                    <p key={index} className="case-text">
                      {caseItem}
                    </p>
                  ))
                ) : (
                  <p className="no-cases-text">No assigned cases available.</p>
                )}
              </div>
            </Tab>
            <Tab eventKey="resolved" title={<strong>Resolved Cases</strong>}>
              <div className="tab-content">
                <h3>Resolved Cases</h3>
                {resolvedCases.length > 0 ? (
                  resolvedCases.map((caseItem, index) => (
                    <p key={index} className="case-text">
                      {caseItem}
                    </p>
                  ))
                ) : (
                  <p className="no-cases-text">No resolved cases available.</p>
                )}
              </div>
            </Tab>
          </Tabs>
        </div>
      </Container>
    </div>
  );
}

export default CaseInfo;
