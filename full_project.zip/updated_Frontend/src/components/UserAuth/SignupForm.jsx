import React, { useState } from "react";
import axios from "axios";
import auth_bg from "../../assets/auth_bg.jpg";

const SignupForm = ({ userType }) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    phoneno: "",
    password: "",
    confirmPassword: "",
    id: "",
  });
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    if (!formData.email || !formData.password || !formData.phoneno) {
      setMessage("Please fill in all required fields");
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setMessage("Passwords don't match!");
      return false;
    }
    if (userType === "Civilian" && !formData.username) {
      setMessage("Username is required for civilians");
      return false;
    }
    if ((userType === "Lawyer" || userType === "Police") && !formData.id) {
      setMessage(
        `Please provide your ${userType === "Lawyer" ? "Lawyer ID" : "Badge ID"}`
      );
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    if (!validateForm()) return;

    setIsLoading(true);
    try {
      const payload = {
        email: formData.email,
        phoneno: formData.phoneno,
        password: formData.password,
        ...(userType === "Civilian"
          ? { username: formData.username }
          : { id: formData.id }),
      };

      const response = await axios.post(
        `http://127.0.0.1:5000/api/${userType.toLowerCase()}/signup`,
        payload,
        { timeout: 10000 }
      );

      setMessage(
        response.data.message ||
          "Signup successful! Please check your email to verify your account."
      );
      setFormData({
        username: "",
        email: "",
        phoneno: "",
        password: "",
        confirmPassword: "",
        id: "",
      });
    } catch (error) {
      setMessage(
        error.response?.data?.message ||
          "Signup failed. Please try again later."
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="vh-100" style={{ backgroundColor: "#5C7285" }}>
      <div className="container py-5 h-100">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col col-xl-10">
            <div
              className="card"
              style={{ borderRadius: "1rem", backgroundColor: "#DBDBDB" }}
            >
              <div className="row g-0">
                <div className="col-md-6 col-lg-5 d-none d-md-block">
                  <img
                    src={auth_bg}
                    alt="signup"
                    className="img-fluid"
                    style={{
                      borderRadius: "1rem 0 0 1rem",
                      height: "100%",
                      width: "100%",
                      objectFit: "cover",
                    }}
                  />
                </div>
                <div className="col-md-6 col-lg-7 d-flex align-items-center">
                  <div className="card-body p-4 p-lg-5 text-black">
                    <form onSubmit={handleSubmit}>
                      <div className="d-flex align-items-center mb-3 pb-1">
                        <span className="h1 fw-bold mb-0 text-info">
                          IPC Nexus
                        </span>
                      </div>
                      <h5 className="fw-normal mb-3 pb-3">
                        Signup as {userType}
                      </h5>

                      {userType === "Civilian" && (
                        <div className="form-outline mb-4">
                          <input
                            type="text"
                            className="form-control form-control-lg"
                            name="username"
                            value={formData.username}
                            onChange={handleChange}
                            placeholder="Enter your username"
                            required
                          />
                        </div>
                      )}
                      {(userType === "Lawyer" || userType === "Police") && (
                        <div className="form-outline mb-4">
                          <input
                            type="text"
                            className="form-control form-control-lg"
                            name="id"
                            value={formData.id}
                            onChange={handleChange}
                            placeholder={`Enter your ${
                              userType === "Lawyer" ? "Lawyer ID" : "Badge ID"
                            }`}
                            required
                          />
                        </div>
                      )}
                      <div className="form-outline mb-4">
                        <input
                          type="email"
                          className="form-control form-control-lg"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="Enter your email"
                          required
                        />
                      </div>
                      <div className="form-outline mb-4">
                        <input
                          type="tel"
                          className="form-control form-control-lg"
                          name="phoneno"
                          value={formData.phoneno}
                          onChange={handleChange}
                          placeholder="Enter your phone number"
                          required
                        />
                      </div>
                      <div className="form-outline mb-4">
                        <input
                          type="password"
                          className="form-control form-control-lg"
                          name="password"
                          value={formData.password}
                          onChange={handleChange}
                          placeholder="Enter your password"
                          required
                        />
                      </div>
                      <div className="form-outline mb-4">
                        <input
                          type="password"
                          className="form-control form-control-lg"
                          name="confirmPassword"
                          value={formData.confirmPassword}
                          onChange={handleChange}
                          placeholder="Confirm password"
                          required
                        />
                      </div>
                      <div className="pt-1 mb-4">
                        <button
                          className="btn btn-dark btn-lg btn-block"
                          type="submit"
                          disabled={isLoading}
                        >
                          {isLoading ? "Signing up..." : "Sign Up"}
                        </button>
                      </div>
                      {message && (
                        <p
                          className={`mt-3 text-center ${
                            message.includes("successful")
                              ? "text-success"
                              : "text-danger"
                          }`}
                        >
                          {message}
                        </p>
                      )}
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SignupForm;
