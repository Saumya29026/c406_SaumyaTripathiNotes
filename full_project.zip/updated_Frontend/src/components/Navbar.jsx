import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Components.css';
import { FaUserCircle } from 'react-icons/fa';

const Navbar = ({ branches }) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-black shadow-sm">
      <div className="container">
        {/* Brand / Logo */}
        <Link className="navbar-brand fw-bold fs-4 text-info" to="/">
          IPC Nexus
        </Link>

        {/* Mobile Toggle Button */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Navbar Links */}
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            {/* Laws Dropdown */}
            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle text-white"
                href="#"
                id="branchesDropdown"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                style={{ transition: 'color 0.3s ease' }}
                onMouseEnter={(e) => (e.target.style.color = 'lightblue')}
                onMouseLeave={(e) => (e.target.style.color = 'white')}
              >
                Laws
              </a>
              <ul className="dropdown-menu bg-black border-0" aria-labelledby="branchesDropdown">
                {branches.map((branch, index) => (
                  <li key={index}>
                    <Link
                      className="dropdown-item text-white"
                      to={`/${branch.toLowerCase().replace(/\s/g, '-')}`}
                      style={{ transition: 'color 0.3s ease' }}
                      onMouseEnter={(e) => (e.target.style.color = 'lightblue')}
                      onMouseLeave={(e) => (e.target.style.color = 'white')}
                    >
                      {branch}
                    </Link>
                  </li>
                ))}
              </ul>
            </li>

            {/* Other Links */}
            <li className="nav-item">
              <Link className="nav-link text-white" to="/register-complaint">
                Register Complaint
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/IPCSections">
                IPC Sections
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/caseInfo">
                CaseInfo
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/EvidenceReport">
              EvidenceReport
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-white" to="/about">
                About Us
              </Link>
            </li>
          </ul>

          {/* Login & Signup Dropdowns */}
          <div className="dropdown">
            <button
              className="btn btn-outline-info dropdown-toggle me-2"
              type="button"
              id="loginDropdown"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              Login
            </button>
            <ul className="dropdown-menu dropdown-menu-end bg-black border-0" aria-labelledby="loginDropdown">
              <li>
                <Link className="dropdown-item text-white" to="/login/civilian">
                  Civilian Login
                </Link>
              </li>
              <li>
                <Link className="dropdown-item text-white" to="/login/lawyer">
                  Lawyer Login
                </Link>
              </li>
              <li>
                <Link className="dropdown-item text-white" to="/login/police">
                  Police Login
                </Link>
              </li>
            </ul>
          </div>
          <div className="dropdown">
            <button
                            className="btn btn-outline-info dropdown-toggle me-2"

              type="button"
              id="signupDropdown"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              Signup
            </button>
            <ul className="dropdown-menu dropdown-menu-end bg-black border-0" aria-labelledby="signupDropdown">
              <li>
                <Link className="dropdown-item text-white" to="/signup/civilian">
                  Civilian Signup
                </Link>
              </li>
              <li>
                <Link className="dropdown-item text-white" to="/signup/lawyer">
                  Lawyer Signup
                </Link>
              </li>
              <li>
                <Link className="dropdown-item text-white" to="/signup/police">
                  Police Signup
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
